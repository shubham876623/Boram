
from os import close
from selenium import webdriver
from selenium.webdriver.chrome.options import  Options
from random import randbytes, seed
from random import random
from time import process_time, sleep, time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common import keys
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
from selenium.webdriver.common.keys import Keys
import pandas as pd
from bs4 import BeautifulSoup 
from selenium.webdriver.common.action_chains import ActionChains
from webdriver_manager.chrome import ChromeDriverManager
import urllib.request
import csv
from urllib.request import urlopen


driver=webdriver.Chrome(ChromeDriverManager().install())   # driver initialization 
id_list=[]
data2_list=[]
# hit the website url
driver.get('https://eclogin.cafe24.com/Shop/')            
driver.maximize_window()
time.sleep(4)

driver.find_element_by_id('mall_id').send_keys('papamarket24')     # enter the mail Id here ..
driver.find_element_by_id('userpasswd').send_keys('!27852hiana!@')    # Enter the password here ..
driver.find_element_by_id('userpasswd').send_keys(Keys.ENTER)
time.sleep(50)
driver.get('https://papamarket24.cafe24.com/admin/php/shop1/c/member_admin_l.php')
time.sleep(2)
driver.find_element_by_xpath('/html/body/div/div[2]/div[2]/form[3]/div[2]/div/div[4]/a[1]').click()   # click on search button 
next_button_list=driver.find_element_by_class_name('mPaginate').find_elements_by_tag_name('li')
print(len(next_button_list))
actions = ActionChains(driver)
soup_for_button=BeautifulSoup(driver.page_source ,'html.parser')

for index, single_button in enumerate( next_button_list) :
    # driver.execute_script("arguments[0].click();", single_button)
    try:
        for _ in range(6):
            actions.send_keys(Keys.SPACE).perform()
        single_button.click()
        time.sleep(3)

        soup=BeautifulSoup(driver.page_source ,'html.parser')
        section_of_all_id=soup.find('div',{'id':'QA_profile2'})  
        all_tr_tag=section_of_all_id.find_all('tr')
        # id_list=[]
        for i in range(2,len(all_tr_tag)):                 # for loop- for id's
            id=all_tr_tag[i].find_all('a')[1].text
            # print(id)
            id_list.append(id)
#         print(len(id_list))    
    except:
        
        anchor=soup_for_button.find('div',{'class':'mPaginate'}).find_all('li')[index].find('a').get('href')
        driver.get('https://papamarket24.cafe24.com'+anchor)
        time.sleep(7)
        soup=BeautifulSoup(driver.page_source ,'html.parser')
        section_of_all_id=soup.find('div',{'id':'QA_profile2'})  
        all_tr_tag=section_of_all_id.find_all('tr')
        # id_list=[]q
        for i in range(2,len(all_tr_tag)):                 # for loop- for id's
            id=all_tr_tag[i].find_all('a')[1].text
            id_list.append(id)

            # print(id)
# driver.find_element_by_class_name('next').click()
print(len(id_list))    
# print(all_tr_tag)
for single_id in id_list:
    url='https://papamarket24.cafe24.com/admin/php/shop1/c/member_admin_d_f.php?user_id={}&shopNo=1&is_cti=&ord_year1=&ord_month1=&ord_day1=&ord_year2=&ord_month2=&ord_day2=&login_year1=&login_month1=&login_year2=&login_month2=&ord_period=&login_period=&ord_date_kind=order_date'.format(single_id)
# # print(url)
    driver.get(url)
    time.sleep(3)
    driver.find_element_by_xpath('/html/body/div[2]/div[2]/div[1]/div[3]/ul/li[2]/a').click()
    time.sleep(5)
    soup=BeautifulSoup(driver.page_source,'html.parser')

    # QA meber info .....

    basic_level_info=soup.find('div',{'id':'QA_member_info1'})
    all_tr_tags_for_basic=basic_level_info.find_all('tr')
    # print(all_tr_tags_for_basic)
    data_list=[]
    id=all_tr_tags_for_basic[0].find('td').text
    membership_level=all_tr_tags_for_basic[1].find('td').find('option',{'value':'1'}).text
    authentication_method=all_tr_tags_for_basic[4].find_all('td')[1].text
    name=all_tr_tags_for_basic[5].find('td').text
    phone_number=all_tr_tags_for_basic[7].find('input').get('value')
    if  len(phone_number) >0:
        phone_number=phone_number
    else:
        phone_number="NA"    

    mobile_number=all_tr_tags_for_basic[8].find('input').get('value')

    address=all_tr_tags_for_basic[10].find('td').text
    if len(address)>0:
        address=address
    else:
        address="No address"    





    # member use info ....


    usage_info=soup.find('div',{'id':'QA_member_use_info'})

    total_revere=usage_info.find_all('tr')[0].find_all('td')[0].text
    total_actual_payment=usage_info.find_all('tr')[0].find_all('td')[1].text
    subscription_path=usage_info.find_all('tr')[1].find_all('td')[0].text
    Member_registration_date=usage_info.find_all('tr')[1].find_all('td')[1].text
    last_acess_date=usage_info.find_all('tr')[2].find_all('td')[0].text
    # print(last_acess_date,"last_acess_dtate")
    # if len(last_acess_date) >0:
    #     last_acess_data=last_acess_date
    # else:
    #     last_acess_data="NA"   

    linked_sns=usage_info.find_all('tr')[3].find_all('td')[0].text
    # print(linked_sns,"lnked sna")

    # plus app useage information 
    plus_app_usage_scetion=soup.find('div',{'id':'QA_member_plusapp_info'})
    table_body=plus_app_usage_scetion.find('tobody',{'class':'empty'})
    if table_body is None :
        try:
            # table_body=plus_app_usage_scetion.find('tobody')


            os=plus_app_usage_scetion.find_all('td')[0].text
            Plus_app_installation_date=plus_app_usage_scetion.find_all('td')[1].text
            login_automatically=plus_app_usage_scetion.find_all('td')[2].text
            automatic_login_cahnge_date=plus_app_usage_scetion.find_all('td')[3].text
            last_acees_date=plus_app_usage_scetion.find_all('td')[4].text

            whether_to_recive_the_notfication=plus_app_usage_scetion.find_all('td')[5].text
            date_of_change_recipent=plus_app_usage_scetion.find_all('td')[6].text
            # Date_of_birth="NA"
            print("data is not avilble ")  

        except:

            os="NA"
            Plus_app_installation_date="NA"
            login_automatically="NA"
            automatic_login_cahnge_date="NA"
            last_acees_date="NA"

            whether_to_recive_the_notfication="NA"
            date_of_change_recipent="NA"
            # Date_of_birth="NA"
            print("data is not avilble ")    

    date_of_birth=soup.find('div',{'id':'QA_member_info2'})
    year=date_of_birth.find_all('tr')[0].find_all('input')[0].get('value')
    month=date_of_birth.find_all('tr')[0].find_all('input')[1].get('value')
    date=date_of_birth.find_all('tr')[0].find_all('input')[2].get('value')
    date_of_birth=str(year)+"-"+str(month)+"-"+str(date)
    Referre_id_td=soup.find('div',{'id':'QA_member_info2'})
    reffer_id=Referre_id_td.find_all('tr')[0].find_all('td')[1].text
    # print(date_of_birth,"dare of birth .............")



    data_list.append(single_id)
    data_list.append(membership_level)
    data_list.append(authentication_method)
    data_list.append(name)
    data_list.append(phone_number)
    data_list.append(mobile_number)
    data_list.append(address)
    data_list.append(total_revere)
    data_list.append(total_actual_payment)
    data_list.append(subscription_path)
    data_list.append(Member_registration_date)
    data_list.append(last_acess_date)
    data_list.append(linked_sns)
    data_list.append(os)
    data_list.append(Plus_app_installation_date)
    data_list.append(login_automatically)
    data_list.append(automatic_login_cahnge_date)
    data_list.append(last_acees_date)
    data_list.append(whether_to_recive_the_notfication)
    data_list.append(date_of_change_recipent)
    data_list.append(date_of_birth)
    data_list.append(reffer_id)


    print("login section start from here ...........................")
    df=pd.DataFrame([data_list])
    df.to_csv('test.csv', mode='a',header=False ,index=False , encoding='utf-8')
    data_list.clear()
# login log  section.........

    driver.find_element_by_xpath('/html/body/div[2]/div[2]/div[1]/div[3]/ul/li[10]').click()
    # time.sleep(5)
    for i in range(0,5):
        time.sleep(5)
        soup1=BeautifulSoup(driver.page_source,'html.parser')
    #print(login_table_section)
        try:
            table=soup1.find('tbody',{'class':'center'})
            if table is not None:
                all_tr_tag=table.find_all('tr')
                # data2_list=[]
                for single_tr in all_tr_tag:
                    
                        ip=single_tr.find_all('td')[1].text
                        pause=single_tr.find_all('td')[2].text
                        data2_list.append(single_id)

                        data2_list.append(ip)
                        data2_list.append(pause)
            else:
                ip="NA"

                pause="NA"
                data2_list.append(single_id)
                data2_list.append(ip)
                data2_list.append(pause) 
            driver.find_element_by_class_name('next').click()    

        except:
            pass   
        # driver.find_element_by_class_name('next').click()    

            
    df=pd.DataFrame([data2_list])
    df.to_csv('test3.csv', mode='a',header=False ,index=False , encoding='utf-8')
    data2_list.clear()

    
################################################################################################################################################









